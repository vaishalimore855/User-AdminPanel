import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";
import { FetchUserObj } from "../Redux/Action";

const UserDetails = () => {
    const { code } = useParams();
    const dispatch = useDispatch();

    const userobj = useSelector((state) => state.user.userobj);

    useEffect(() => {
        dispatch(FetchUserObj(code));
    }, [code]);

    return (
        <div>
            <div className="card">
                <div className="card-header" style={{ textAlign: 'center' }}>
                    <h2>User Details</h2>
                </div>
                <div className="card-body" style={{ textAlign: 'center' }}>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="card">
                                <div className="card-body">
                                    <h5 className="card-title">Id: {userobj.id}</h5>
                                    <p className="card-text">Name: {userobj.name}</p>
                                    <p className="card-text">Email: {userobj.email}</p>

                                    <p className="card-text">Role: {userobj.role}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="card-footer" style={{ textAlign: 'center' }}>
                    <Link className="btn btn-danger" to={'/user'}>Back</Link>
                </div>
            </div>
        </div>
    );
}

export default UserDetails;
